class LLMInterface:
    pass
