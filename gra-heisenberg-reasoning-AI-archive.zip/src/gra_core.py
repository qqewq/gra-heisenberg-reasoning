class GRACore:
    pass
