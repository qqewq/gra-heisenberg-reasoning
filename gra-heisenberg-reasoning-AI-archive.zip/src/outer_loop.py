class OuterLoopController:
    pass
