# GRA–Heisenberg–LLM

Two-loop meta-cognitive AI architecture.
