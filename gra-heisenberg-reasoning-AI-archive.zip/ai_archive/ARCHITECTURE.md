Two-loop reasoning architecture.
