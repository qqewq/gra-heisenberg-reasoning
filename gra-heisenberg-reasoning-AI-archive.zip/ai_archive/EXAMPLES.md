Illustrative AI reasoning examples.
