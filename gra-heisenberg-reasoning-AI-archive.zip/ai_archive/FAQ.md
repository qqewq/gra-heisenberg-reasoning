Research prototype, not AGI.
