Degeneracy collapse via orthogonal constraints.
